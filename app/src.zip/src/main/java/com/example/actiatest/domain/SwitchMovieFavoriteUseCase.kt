package com.example.actiatest.domain

import com.example.actiatest.model.Error
import com.example.actiatest.model.MoviesRepository
import com.example.actiatest.model.database.Movie

class SwitchMovieFavoriteUseCase(private val repository: MoviesRepository) {
    suspend operator fun invoke(movie: Movie):Error?= repository.switchFavorite(movie)
}